package project.on.manegement.Employee.Management.System;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class NewPageController {

	@RequestMapping("app")
public String get() {
		
		
		return "mvc";
}

	@RequestMapping("connect")
public String get2() {
		
		
		return "new";
}
	
	
}
