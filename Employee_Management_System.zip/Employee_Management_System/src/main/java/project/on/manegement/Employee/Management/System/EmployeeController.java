package project.on.manegement.Employee.Management.System;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {
	
	@Autowired
	SessionFactory factory;
	@GetMapping("allemployee")
	
	List<Employee> GetAll(){
		
		Session  session = factory.openSession();
		
		List <Employee> li = session.createCriteria(Employee.class).list();
		return li;
	}	
	@GetMapping("onlyemployee/{id}")
	public Employee getEmployee(@PathVariable int id) {
		Session session = factory.openSession();
		Employee employee =  session.load(Employee.class,  id);
		return employee;
	}
	@PostMapping("postemployee")
	public List<Employee> addEmployee(@RequestBody Employee employee){
		Session  session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.save(employee);
		tx.commit();
		List<Employee> list = GetAll();
		return list;
	}
	@PutMapping("putemployee")
	public List<Employee> updateEmployee(@RequestBody Employee client){
		Session  session = factory.openSession();
		Transaction tx = session.beginTransaction();
		session.saveOrUpdate(client);
		tx.commit();
		List<Employee> list = GetAll();
		return list;
	}
	@DeleteMapping("removeEmployee/{id}")
	public List<Employee> deleteEmployee(@PathVariable int id){
		Session session = factory.openSession();
		Employee employee =session.load(Employee.class, id);
		Transaction tx = session.beginTransaction();
		session.delete(employee);
		tx.commit();
		List<Employee> list = GetAll();
		
		
		return list;
	}
	
			
	

}
